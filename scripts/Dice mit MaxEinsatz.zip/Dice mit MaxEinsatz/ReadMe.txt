===============================================================================
 Name: 		Dice Minigame mit MaxEinsatz for Streamlabs Bot
 Version: 	1.2.8.1
 Creator: 	Bare7a und 132Beats
 Website:	https://github.com/Bare7a/Streamlabs-Chatbot-Scripts
===============================================================================
 - Enable/Disable using the command when the stream is offline
 - Enable/Disable using custom betting ammounts
 - Enable/Disable cooldown / user cooldown
 - Enable/Disable cooldown / user cooldown messages
 - Customisable command name
 - Customisable permission for using the command
 - Customisable winning multipliers
 - Customisable cooldown / user cooldown timers 
 - Customisable response messages
===============================================================================
